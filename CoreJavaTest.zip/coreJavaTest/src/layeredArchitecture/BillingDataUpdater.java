package layeredArchitecture;

public class BillingDataUpdater {
	   public void updateBillingData(/* Add parameters for the data */) {
	       
	   }

}
