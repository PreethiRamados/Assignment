package layeredArchitecture;

public class CallRecordFetcher {
	public void fetchCallRecords() {
	       
	   }

}
