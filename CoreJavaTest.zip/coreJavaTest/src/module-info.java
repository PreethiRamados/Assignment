module coreJavaTest {
}