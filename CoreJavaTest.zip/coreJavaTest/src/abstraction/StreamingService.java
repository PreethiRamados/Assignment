package abstraction;

public class StreamingService implements DigitalService {
	 
	public void login(String username, String password) {
		System.out.println("Logged in to Streaming Service with username: " + username);
	}
 
		public void logout() {
		System.out.println("Logged out from Streaming Service.");
	}
 
	
	public void accessContent(String contentId) {
		System.out.println("Accessing content with ID: " + contentId + " on Streaming Service.");
	}
 

	public void updateProfile(String firstName, String lastName, String email) {
		System.out.println("Profile updated on Streaming Service for: " + firstName + " " + lastName);
	}
}